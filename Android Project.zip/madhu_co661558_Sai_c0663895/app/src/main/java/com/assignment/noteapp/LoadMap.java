package com.assignment.noteapp;

import java.util.ArrayList;
import java.util.List;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.GoogleMap.InfoWindowAdapter;
import com.google.android.gms.maps.GoogleMap.OnMapClickListener;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button; 
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


public class LoadMap extends FragmentActivity implements LocationListener{
	
	private Button btn_locatOk;
	Context context = this;
    GoogleMap googlemap;
    Bundle logLang;
    String latstr,longstr, radius;
    EditText edtxt_locatName;
    DBAdapter dba;
    Spinner spin;
    Cursor searchCursor;
    String[] location_name;
    final ArrayList<String> list_options=new ArrayList<String>();
    
    int numPoints;
	double phase;
	boolean isGPSEnabled = false;
	Bundle b;
	int bundle_id;
	String alName,alNote;
	boolean alStatus,alVibration;
	String myAlarmId;
	String latitudeString,longitudeString;
	String locationNameString ;
	
	Location location; // location
	protected LocationManager locationManager;
	String abc ;
	String latlong;
	
	// The minimum distance to change Updates in meters
	private static final long MIN_DISTANCE_CHANGE_FOR_UPDATES = 1; // 1 meters
	

	// The minimum time between updates in milliseconds
	private static final long MIN_TIME_BW_UPDATES = 5000; // 5 second

	
	
	
	@SuppressLint("NewApi")
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.load_map);
	
		try
		{
			
			
			b = getIntent().getExtras();
			dba = new DBAdapter(getApplicationContext());
			edtxt_locatName=(EditText)findViewById(R.id.edtxt_locatName);
			btn_locatOk=(Button)findViewById(R.id.btn_locatOk);
			initmap();
			//call_selected_location();
			
			int currentapiVersion = android.os.Build.VERSION.SDK_INT;
	        if (currentapiVersion <= android.os.Build.VERSION_CODES.HONEYCOMB){
	        	//Toast.makeText(getApplicationContext(), ">"+ String.valueOf(currentapiVersion), Toast.LENGTH_LONG).show();
	        	edtxt_locatName.setTextColor(Color.BLACK);
	        	
	        	
	        } else{
	        	
	        	edtxt_locatName.setTextColor(Color.WHITE);
	        	
	        }
			
			
			
			
			/*btn_locatOk.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
				try{
					
					dba.open();
					dba.insert_my_location(edtxt_locatName.getText().toString(),latstr,longstr,radius);
					System.out.println("RECORD SAVED------>>>"+edtxt_locatName.getText().toString()+String.valueOf(latstr)+String.valueOf(longstr));
					Toast.makeText(getApplicationContext(), "Saved", Toast.LENGTH_LONG).show();
					Cursor c = dba.get_my_location_id(latstr,longstr);
					c.moveToFirst();
					System.out.println("----->>"+c.getCount());
					int loc_id = Integer.parseInt(c.getString(c.getColumnIndex("location_id")));
					Toast.makeText(getApplicationContext(), "----->> "+loc_id, Toast.LENGTH_LONG).show();
					System.out.println("----->>"+loc_id);
					
					if(Constant.L_MESSAGE_FORM_ID == 1)
					{
						Intent i = new Intent(getApplicationContext(),L_Message_Form.class);
						Constant.LOCATION_ID = loc_id;
						System.out.println("---->>>>>"+Constant.LOCATION_ID);
						startActivity(i);
						Constant.L_MESSAGE_FORM_ID=0;
					}
					else if(Constant.L_NOTE_FORM_ID == 1)
					{
						Intent i = new Intent(getApplicationContext(),L_Note_Form.class);
						
						Constant.LOCATION_ID=loc_id;
						startActivity(i);
						Constant.L_NOTE_FORM_ID=0;
					}
					else if(Constant.L_PROFILE_FORM_ID == 1)
					{
						Intent i = new Intent(getApplicationContext(),L_Profile_Form.class);
						
						Constant.LOCATION_ID=loc_id;
						startActivity(i);
						Constant.L_PROFILE_FORM_ID=0;
					}
					else if(Constant.L_MAIL_FORM_ID == 1)
					{
						
						Intent i = new Intent(getApplicationContext(),L_Mail_Form.class);
						
						Constant.LOCATION_ID=loc_id;
						startActivity(i);
						Constant.L_MAIL_FORM_ID=0;
					}
					
					else
					{
						
						Intent i = new Intent(getApplicationContext(),L_WiFi_Form.class);
						
						Constant.LOCATION_ID=loc_id;
						startActivity(i);
						Constant.L_WIFI_FORM_ID=0;
						
					}
					dba.close();
					//startActivity(i);
					finish();
					
									
										
				}catch(Exception e)
				{
					System.out.println("ERROR AT btn_ok---->>>>"+e.toString());
				}
				}
				
			});
			*/
			
		}
		catch(Exception e)
		{
			System.out.println("errorrrrrrrrr-------------"+e.toString());
			//Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
		}
		
	
	}
	
	
	
	/*private void addTwittertoMap() {
		// TODO Auto-generated method stub
		LatLng pos = new LatLng(37.7769904, -122.4169725);
        MarkerOptions mm = new MarkerOptions();
        googlemap.addMarker(new MarkerOptions()
                .title("Twitter")
                .snippet("Twitter HQ")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))
                .position(pos)
                );
	}*/

	/*public void call_selected_location()
	{
		//Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show();
		
		try
		{
			dba.open();
			Cursor c = dba.getAll_tbl_my_location(Constant.LOCATION_ID);
			
			if(c.moveToFirst())
			{
				do
				{
					latstr = c.getString(c.getColumnIndex("lattitude"));//c.getDouble(1);
					longstr = c.getString(c.getColumnIndex("longitude"));//c.getDouble(2);
					//Toast.makeText(getApplicationContext(), "Lat = " + String.valueOf(latstr) + "\n Long = " + String.valueOf(longstr), Toast.LENGTH_LONG).show();
				}while (c.moveToNext());
			}
			
			googlemap.clear();
			MarkerOptions m = null;
			LatLng latlng = new LatLng(Double.parseDouble(latstr), Double.parseDouble(longstr));//new LatLng(latstr, longstr);
			googlemap.addMarker(new MarkerOptions().position(latlng));   
			googlemap.animateCamera(CameraUpdateFactory.newLatLng(latlng));
			
			dba.close();
		}
		catch(Exception e)
		{
			//Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
		}
	}
	
*/

	/*public void click_btn_locatOk(View v)
	{
		dba.open();
		dba.insert_my_location(edtxt_locatName.getText().toString(),latstr,longstr,radius);
		
		Toast.makeText(getApplicationContext(), "Saved", Toast.LENGTH_LONG).show();
		Intent i = new Intent(getApplicationContext(),L_Note_Form.class);
		
		i.putExtra("location_id", dba.get_my_location_id(latstr,longstr));
		dba.close();
		startActivity(i);
		finish();
		
	}*/
	
	public void initmap() {
		// TODO Auto-generated method stub
		
		try{
		
		SupportMapFragment mf = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
	        googlemap = mf.getMap();
	        
	        googlemap.setMyLocationEnabled(true);
	        googlemap.setMapType(GoogleMap.MAP_TYPE_HYBRID); 
	        
	        
	     // Setting a custom info window adapter for the google map		
			googlemap.setInfoWindowAdapter(new InfoWindowAdapter() {
				
				// Use default InfoWindow frame
				@Override
				public View getInfoWindow(Marker arg0) {				
					return null;
				}			
				
				// Defines the contents of the InfoWindow
				@Override
				public View getInfoContents(Marker arg0) {
					
					// Getting view from the layout file info_window_layout
					View v = getLayoutInflater().inflate(R.layout.info_window_layout, null);
					
					// Getting the position from the marker
					LatLng latLng = arg0.getPosition();
					
					// Getting reference to the TextView to set latitude
					TextView tvLat = (TextView) v.findViewById(R.id.tv_lat);
					
					// Getting reference to the TextView to set longitude
					TextView tvLng = (TextView) v.findViewById(R.id.tv_lng);
					latstr = String.valueOf(latLng.latitude);
					longstr = String.valueOf(latLng.longitude);
					Toast.makeText(getApplicationContext(), String.valueOf(latstr)+" "+String.valueOf(longstr), Toast.LENGTH_LONG).show();
					// Setting the latitude 
					tvLat.setText("Latitude:" + latLng.latitude);
					
					// Setting the longitude
					tvLng.setText("Longitude:"+ latLng.longitude);
					
					// Returning the view containing InfoWindow contents
					return v;
					
				}
				
			});
			
			
			// Adding and showing marker while touching the GoogleMap
			googlemap.setOnMapClickListener(new OnMapClickListener() {
				
				@Override
				public void onMapClick(LatLng arg0) {
					// Clears any existing markers from the GoogleMap
					googlemap.clear();

					// Creating an instance of MarkerOptions to set position
					MarkerOptions markerOptions = new MarkerOptions();
					
					// Setting position on the MarkerOptions
					markerOptions.position(arg0);				
					
					// Animating to the currently touched position
					googlemap.animateCamera(CameraUpdateFactory.newLatLng(arg0));	
					
					// Adding marker on the GoogleMap
					Marker marker = googlemap.addMarker(markerOptions);
					
					// Showing InfoWindow on the GoogleMap-
					marker.showInfoWindow();

					 PolylineOptions options = new PolylineOptions();
					    radius = String.valueOf(0.0008); //What is that?
					  // double  radius1 = Double.parseDouble(radius);
					    numPoints = 100;
					    phase = 2 * Math.PI / numPoints;
					    for (int i = 0; i <= numPoints; i++) {
					        options.add(new LatLng(Double.parseDouble(latstr) + Double.parseDouble(radius) * Math.sin(i * phase),
					                Double.parseDouble(longstr) + Double.parseDouble(radius) * Math.cos(i * phase))); 
					    }
					    int color = Color.RED;
					    googlemap.addPolyline(options
					            .color(color)
					            .width(2));
					
				
					
				}
			});
		}catch(Exception e)
		{
			System.out.println("ERROR AT initmap method"+e.toString());
		}
	}
	

	
	/* @Override  
		public void onBackPressed() {
		 if(Constant.L_MESSAGE_FORM_ID == 1)
			{
				Intent i = new Intent(getApplicationContext(),L_Message_Form.class);
				
				startActivity(i);
				Constant.L_MESSAGE_FORM_ID=0;
			}
			else if(Constant.L_NOTE_FORM_ID == 1)
			{
				Intent i = new Intent(getApplicationContext(),L_Note_Form.class);
				
				startActivity(i);
				Constant.L_NOTE_FORM_ID=0;
			}
			else if(Constant.L_PROFILE_FORM_ID == 1)
			{
				Intent i = new Intent(getApplicationContext(),L_Profile_Form.class);
				
				startActivity(i);
				Constant.L_PROFILE_FORM_ID=0;
			}
			else if(Constant.L_MAIL_FORM_ID == 1)
			{
				
				Intent i = new Intent(getApplicationContext(),L_Mail_Form.class);
				
				startActivity(i);
				Constant.L_MAIL_FORM_ID=0;
			}
			
			else
			{
				
				Intent i = new Intent(getApplicationContext(),L_WiFi_Form.class);
				
				startActivity(i);
				Constant.L_WIFI_FORM_ID=0;
				
			}

		}
*/
	@Override
	public void onLocationChanged(Location arg0) {
		// TODO Auto-generated method stub
		
		if (isGPSEnabled) {
            if (location == null) {
                locationManager.requestLocationUpdates(
                        LocationManager.GPS_PROVIDER,
                        MIN_TIME_BW_UPDATES,
                        MIN_DISTANCE_CHANGE_FOR_UPDATES, this);
                Log.d("GPS Enabled", "GPS Enabled");
                if (locationManager != null) {
                    location = locationManager
                            .getLastKnownLocation(LocationManager.GPS_PROVIDER);
                    if (location != null) {
                    	latstr = String.valueOf(location.getLatitude());
                    	longstr = String.valueOf(location.getLongitude());
                    }
                }
            }
        }
		
	}

	@Override
	public void onProviderDisabled(String provider) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onProviderEnabled(String provider) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		// TODO Auto-generated method stub
		
	}
	 
	
}

