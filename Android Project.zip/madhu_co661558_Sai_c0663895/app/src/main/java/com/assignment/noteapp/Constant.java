package com.assignment.noteapp;

public class Constant {
	
	public static int ALARM_ID;
	public static int LOCATION_ID;
	public static int L_MESSAGE_FORM_ID;
	public static int L_NOTE_FORM_ID;
	public static int L_MAIL_FORM_ID;
	public static int L_WIFI_FORM_ID;
	public static int L_PROFILE_FORM_ID;
	
	
	public static String FLAG;
	
	public static int T_PROFILE_HOME_ID;
	public static int T_WIFI_HOME_ID;
	public static int PROFILE_PROXIMITY;
	public static int NOTE_PROXIMITY;
}
